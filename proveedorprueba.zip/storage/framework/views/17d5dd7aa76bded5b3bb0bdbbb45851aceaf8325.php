<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <br>
            <?php echo e(__('PROVEEDORES REGISTRADOS')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="hidden space-x-8 sm:-my-px sm:ml-10 sm:flex">

                </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("BIENVENIDO")); ?> <?php echo e(Auth::user()->name); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("Datos Registrados:")); ?>

                    <br>
                    <br>
                    <br>
                    <table   class="table table-bordered display nowrap" cellpacing="0"  style="width:100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NOMBRE PROVEEDOR</th>
                                <th>RFC</th>
                                <th>CALLE</th>
                                <th>COLONIA</th>
                                <th>DELEGACION</th>
                                <th>CUIDAD</th>
                                <th>ESTADO</th>
                                <th>CP</th>
                                <th>BANCO</th>
                                <th>CUENTA</th>
                                <th>CLABE</th>
                                <th>ESTADO</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $datosproveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datosproveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($datosproveedor->id); ?></td>
                            <td><?php echo e($datosproveedor->nombre); ?></td>
                            <td><?php echo e($datosproveedor->rfc); ?></td>
                            <td><?php echo e($datosproveedor->calle); ?></td>
                            <td><?php echo e($datosproveedor->colonia); ?></td>
                            <td><?php echo e($datosproveedor->delegacion); ?></td>
                            <td><?php echo e($datosproveedor->cuidadd); ?></td>
                            <td><?php echo e($datosproveedor->estado); ?></td>
                            <td><?php echo e($datosproveedor->cp); ?></td>
                            <td><?php echo e($datosproveedor->banco); ?></td>
                            <td><?php echo e($datosproveedor->cuenta); ?></td>
                            <td><?php echo e($datosproveedor->clabe); ?></td>
                            <td><?php echo e($datosproveedor->constancia); ?></td>
                            <td><?php echo e($datosproveedor->cumpli); ?></td>
                            <td><?php echo e($datosproveedor->estado_cuenta); ?></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="flex items-center justify-center mt-4">               
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ml-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-3']); ?>
            <a href="/user/create"> <?php echo e(__('Ingresa tus datos')); ?></a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <br>
        <br>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

    


<?php /**PATH C:\xampp\htdocs\proveedor\resources\views/user/indexuser.blade.php ENDPATH**/ ?>