<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=h1, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>ADMIN POST</h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\proveedor\resources\views/post.blade.php ENDPATH**/ ?>